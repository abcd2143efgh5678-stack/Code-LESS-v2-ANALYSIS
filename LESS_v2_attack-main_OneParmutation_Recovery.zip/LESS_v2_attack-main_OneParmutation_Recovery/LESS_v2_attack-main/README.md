# LESS_v2_attack
=======
Here NOT_TO_PUBLISH = 1, TO_PUBLISH = 0. 

How to run the simulation code: 
======================

1 - Goto the folder LESS-main/Utilities/Benchmarking 

2 - Create a folder named “build” 

3 - Run cmake and then make: 

4 - cmake ../ 

5 - make 
6 - Run any executable file: Ex: ./LESS_benchmark_cat_252_45 


Till now, we have done in the simulation code as far:
=============

1 - Assume that we can change the value of an element “flags_tree_to_publish[1]” of the array “flags_tree_to_publish” in the function “compute_seeds_to_publish” (this function belongs in the file “Reference_Implementation/lib/seedtree.c”) from 1 to 0.

2 - We modified the function “compute_seeds_to_publish” that follows the above assumption to “compute_seeds_to_publish_faulted” (We add the extra line:  “flags_tree_to_publish[1]=TO_PUBLISH”;--line number 213). The value of TO_PUBLISH is 0.

3 - If we modify the value of “flags_tree_to_publish[1]”, the signature will be faulty. Using this fault signature, we can find the secret key. See lines: 596-1037 of the LESS_sign function in the file “Reference_Implementation/lib/LESS.c”


Simulation Update:
========================
We will update the simulation code to modify the function compute_seeds_to_publish that follows the above assumption to compute_seeds_to_publish_faulted (We add the extra line: flags_tree_to_publish[r]=TO_PUBLISH), where r is random position. The value of TO_PUBLISH is 0. Here, we will make a successful fault detector to detect the fault signature from where we can find the secret.

Practical attack Locations and possibilities:
==========================================

1 - Here, we have to modify a value of flags_tree_to_publish[r]=NOT_TO_PUBLISH to TO_PUBLISH, where r is any random position of this array in the function compute_seeds_to_publish. This modification can be done by flipping or stuck at zero or skipping the instruction “parent_node = PARENT(current_node) + (off[level-1] >> 1);” (used in the function compute_seeds_to_publish).

2 - The above modification can be possible if we modify a value of the array indices_to_publish, which is initiated in the LESS_sign function (Reference_Implementation/lib/LESS.c) and used in the function compute_seeds_to_publish. This modification can be done by bit-flipping or stuck at zero. 

Please go through the code, and we can arrange a meeting for further information or an explanation. 
================================================================================================

>>>>>>> ceb9574 (commit)
