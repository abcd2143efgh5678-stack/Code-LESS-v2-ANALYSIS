/**
 *
 * Reference ISO-C11 Implementation of LESS.
 *
 * @version 1.2 (February 2025)
 *
 * @author Alessandro Barenghi <alessandro.barenghi@polimi.it>
 * @author Gerardo Pelosi <gerardo.pelosi@polimi.it>
 * @author Floyd Zweydinger <zweydfg8+github@rub.de>
 *
 * This code is hereby placed in the public domain.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **/

//
#include <string.h> // memcpy, memset
#include<stdio.h>
#include "LESS.h"
#include "canonical.h"
#include "seedtree.h"
#include "rng.h"
#include "utils.h"
#include "fips202.h"
#include "sha3.h"

// Extra Part
generator_mat_t G_Copy;
normalized_IS_t A_i_Copy;

//monomial_t Q_tilde_1_1;
//generator_mat_t G_Copy_1;
//normalized_IS_t A_i_Copy_1;
uint8_t cf_monom_actions_check[N8];

invertible_mat_K S_tilde;
monomial_t P_tilde;
monomial_t P_tilde_dash;

monomial_t_K Q_r_sign;
monomial_t_K Q_r_vrfy;

monomial_t_K Q_r_sign_update;
monomial_t_NK Q_c_sign;
normalized_IS_t B_i_copy;
normalized_IS_t G_row_final_sign;
normalized_IS_t G_column_final_sign;
normalized_IS_t A_i_check_sign;

monomial_t_K Q_r_vrfy_update;
monomial_t_NK Q_c_vrfy;
normalized_IS_t C_i_copy;
normalized_IS_t G_row_final_vrfy;
normalized_IS_t G_column_final_vrfy;
normalized_IS_t A_i_check_vrfy;
//generator_mat_t G_prime_dash;

monomial_t_K Q_r_vrfy_update_inv;
monomial_t_NK Q_c_sign_inv;
monomial_t_K Q_r_bar;
monomial_t_NK Q_c_bar;
monomial_t_K Q_r_bar_inv;
monomial_t_NK Q_c_bar_inv;

monomial_t P_bar;
monomial_t P_tilde_inv;
monomial_t mult_P_bar_P_tilde_inv;

monomial_t Q_guess;
monomial_t Q_guess_transpose;
monomial_t Q_guess_inv;
//Extra Function
void monomial_mat_K(monomial_t_K *mat1, monomial_t_K *mat2){

    invertible_mat_K Q_check;
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<K; j1++){
            Q_check.value[i1][j1] = 0;
        }
        Q_check.value[i1][mat2->permutation[i1]] = mat2->coefficients[mat2->permutation[i1]]; 
    }
    for(uint32_t j1=0; j1<K; j1++){
        for(uint32_t i1=0; i1<K; i1++){
            if(Q_check.value[i1][j1] != 0){
                mat1->permutation[j1] = i1;
                mat1->coefficients[j1] = Q_check.value[i1][j1];
            }
        } 
    }
}

void mult_mono_normalmat(normalized_IS_t *mult_mat, normalized_IS_t *mat1, monomial_t_K *mat2){
    normalized_IS_t mat1_copy;
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<N-K; j1++){
            mat1_copy.values[i1][j1] = mat1->values[i1][j1];
        }
    }

    invertible_mat_K Q_check;
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<K; j1++){
            Q_check.value[i1][j1] = 0;
        }
        Q_check.value[i1][mat2->permutation[i1]] = mat2->coefficients[mat2->permutation[i1]]; 
    }
    //invertible_mat_K Q_check;
    monomial_t_K Q_check1;

    for(uint32_t j1=0; j1<K; j1++){
        for(uint32_t i1=0; i1<K; i1++){
            if(Q_check.value[i1][j1] != 0){
                Q_check1.permutation[j1] = i1;
                Q_check1.coefficients[j1] = Q_check.value[i1][j1];
            }
        }
    }
    normalized_IS_t mult_check;
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<N-K; j1++){
            mult_check.values[Q_check1.permutation[i1]][j1] = fq_mul(mat1_copy.values[i1][j1], Q_check1.coefficients[i1]);
        }
    }
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<N-K; j1++){
            FQ_ELEM sum = 0;
            for(uint32_t k1=0; k1<K; k1++){
                sum = fq_add(sum, fq_mul(Q_check.value[i1][k1],mat1_copy.values[k1][j1]));
            }
            mult_mat->values[i1][j1] = sum;
            if(mult_check.values[i1][j1]!=mult_mat->values[i1][j1]){
                printf("error in multiplication!!!!!!!!!!!!!!!!\n");
                break;
            }
        }
    }

}

void initialize_monomial_N(monomial_t *mat1){
    for(uint32_t i=0; i<N; i++){
        mat1->coefficients[i] = 1;
        mat1->permutation[i] = i;
    }
}
void initialize_inv_K(invertible_mat_K *mat1){
    for(uint32_t i1=0; i1<K; i1++){
        for(uint32_t j1=0; j1<K; j1++)
            mat1->value[i1][j1] =0;
        mat1->value[i1][i1] =1;
    }
}
void mat_copy_N(generator_mat_t *mat1, generator_mat_t *mat2){
    for(uint32_t i=0; i<K; i++){
        for(uint32_t j=0; j<N; j++)
            mat1->values[i][j] = mat2->values[i][j];
    }
}
int mat_compare_N(generator_mat_t *mat1, generator_mat_t *mat2){
    for(uint32_t i=0; i<K; i++){
        for(uint32_t j=0; j<N; j++){
            if(mat1->values[i][j] != mat2->values[i][j])
                return 0;
        }
    }
    return 1;
}
void normal_mat_copy_N_NK(normalized_IS_t *mat1, normalized_IS_t *mat2){
    for(uint32_t i=0; i<K; i++){
        for(uint32_t j=0; j<N-K; j++)
            mat1->values[i][j] = mat2->values[i][j];
    }
}
int normal_mat_compare_N_NK(normalized_IS_t *mat1, normalized_IS_t *mat2){
    for(uint32_t i=0; i<K; i++){
        for(uint32_t j=0; j<N-K; j++){
            if(mat1->values[i][j] != mat2->values[i][j])
                return 0;
        }
    }
    return 1;
}
//mat1 = mat2 
void monomial_copy_N(monomial_t *mat1, monomial_t *mat2){
    for(uint32_t i=0; i<N; i++){
        mat1->permutation[i] = mat2->permutation[i];
        mat1->coefficients[i] = mat2->coefficients[i];
    }
}
void monomial_copy_K(monomial_t_K *mat1, monomial_t_K *mat2){
    for(uint32_t i=0; i<K; i++){
        mat1->permutation[i] = mat2->permutation[i];
        mat1->coefficients[i] = mat2->coefficients[i];
    }
}

void monomial_copy_NK(monomial_t_NK *mat1, monomial_t_NK *mat2){
    for(uint32_t i=0; i<N-K; i++){
        mat1->permutation[i] = mat2->permutation[i];
        mat1->coefficients[i] = mat2->coefficients[i];
    }
}
// mat1 = mat2? 1 : 0
int monomial_compare_N(monomial_t *mat1, monomial_t *mat2){
    for(uint32_t i=0; i<N; i++){
        if(mat1->permutation[i]!=mat2->permutation[i] || mat1->coefficients[i]!=mat2->coefficients[i]){
            return 0;
        }
    }
    return 1;
}
int monomial_compare_K(monomial_t_K *mat1, monomial_t_K *mat2){
    for(uint32_t i=0; i<K; i++){
        if(mat1->permutation[i]!=mat2->permutation[i] || mat1->coefficients[i]!=mat2->coefficients[i]){
            return 0;
        }
    }
    return 1;
}
int monomial_compare_NK(monomial_t_NK *mat1, monomial_t_NK *mat2){
    for(uint32_t i=0; i<N-K; i++){
        if(mat1->permutation[i]!=mat2->permutation[i] || mat1->coefficients[i]!=mat2->coefficients[i]){
            return 0;
        }
    }
    return 1;
}

// P_transpose = P^T
void monomial_transpose_N(monomial_t *P_transpose, monomial_t *P){

    for(uint32_t i1=0; i1<N; i1++){
        P_transpose->permutation[P->permutation[i1]] = i1;
    }
    for(uint32_t i1=0; i1<N; i1++){
        P_transpose->coefficients[i1] = P->coefficients[P_transpose->permutation[i1]];
    }
}

void monomial_transpose_K(monomial_t_K *P_transpose, monomial_t_K *P){

    for(uint32_t i1=0; i1<K; i1++){
        P_transpose->permutation[P->permutation[i1]] = i1;
    }
    for(uint32_t i1=0; i1<K; i1++){
        P_transpose->coefficients[i1] = P->coefficients[P_transpose->permutation[i1]];
    }
}

void monomial_transpose_NK(monomial_t_NK *P_transpose, monomial_t_NK *P){

    for(uint32_t i1=0; i1<N-K; i1++){
        P_transpose->permutation[P->permutation[i1]] = i1;
    }
    for(uint32_t i1=0; i1<N-K; i1++){
        P_transpose->coefficients[i1] = P->coefficients[P_transpose->permutation[i1]];
    }
}
// res = to_invert^-1
void monomial_inv_K(monomial_t_K *res,
                  const monomial_t_K *const to_invert) {
    for(uint32_t i = 0; i < K; i++) {
        res->permutation[to_invert->permutation[i]] = i;
        res->coefficients[to_invert->permutation[i]] =
            fq_inv(to_invert->coefficients[i]);
    }
} 

void monomial_inv_NK(monomial_t_NK *res,
                  const monomial_t_NK *const to_invert) {
    for(uint32_t i = 0; i < N-K; i++) {
        res->permutation[to_invert->permutation[i]] = i;
        res->coefficients[to_invert->permutation[i]] =
            fq_inv(to_invert->coefficients[i]);
    }
}
//res = Q1.Q2
void monomial_mult_N(monomial_t *res,
                  const monomial_t *const Q1, const monomial_t *const Q2) {
    for(uint32_t i = 0; i < N; i++) {
        res->permutation[i] = Q1->permutation[Q2->permutation[i]];
    }
    for(uint32_t i = 0; i < N; i++) {
        res->coefficients[i] = fq_mul(Q1->coefficients[Q2->permutation[i]], Q2->coefficients[i]);
    }
}

void monomial_mult_K(monomial_t_K *res,
                  const monomial_t_K *const Q1, const monomial_t_K *const Q2) {
    for(uint32_t i = 0; i < K; i++) {
        res->permutation[i] = Q1->permutation[Q2->permutation[i]];
    }
    for(uint32_t i = 0; i < K; i++) {
        res->coefficients[i] = fq_mul(Q1->coefficients[Q2->permutation[i]], Q2->coefficients[i]);
    }
}

void monomial_mult_NK(monomial_t_NK *res,
                  const monomial_t_NK *const Q1, const monomial_t_NK *const Q2) {
    for(uint32_t i = 0; i < N-K; i++) {
        res->permutation[i] = Q1->permutation[Q2->permutation[i]];
    }
    for(uint32_t i = 0; i < N-K; i++) {
        res->coefficients[i] = fq_mul(Q1->coefficients[Q2->permutation[i]], Q2->coefficients[i]);
    }
}
/////////////////////////////////////
uint8_t SF_G_new [NUM_KEYPAIRS-1][RREF_MAT_PACKEDBYTES];
void LESS_keygen(prikey_t *SK,
                 pubkey_t *PK) {
    /* generating private key from a single seed */
    randombytes(SK->compressed_sk, PRIVATE_KEY_SEED_LENGTH_BYTES);

    /* expanding it onto private seeds */
    SHAKE_STATE_STRUCT sk_shake_state;
    initialize_csprng(&sk_shake_state, SK->compressed_sk, PRIVATE_KEY_SEED_LENGTH_BYTES);

    /* Generating public code G_0 */
    csprng_randombytes(PK->G_0_seed, SEED_LENGTH_BYTES, &sk_shake_state);

    rref_generator_mat_t G0_rref;
    generator_sample(&G0_rref, PK->G_0_seed);

    generator_mat_t tmp_full_G;
    generator_rref_expand(&tmp_full_G, &G0_rref);

    /* The first private key monomial is an ID matrix, no need for random
     * generation, hence NUM_KEYPAIRS-1 */
    unsigned char private_monomial_seeds[NUM_KEYPAIRS - 1][PRIVATE_KEY_SEED_LENGTH_BYTES];
    for (uint32_t i = 0; i < NUM_KEYPAIRS - 1; i++) {
        csprng_randombytes(private_monomial_seeds[i],
                           PRIVATE_KEY_SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }

    /* note that the first "keypair" is just the public generator G_0, stored
     * as a seed and the identity matrix (not stored) */
    for (uint32_t i = 0; i < NUM_KEYPAIRS - 1; i++) {
        uint8_t is_pivot_column[N_pad] = {0};
        /* expand inverse monomial from seed */
        monomial_t private_Q;
        monomial_t private_Q_inv;
        monomial_sample_prikey(&private_Q_inv, private_monomial_seeds[i]);
        monomial_inv(&private_Q, &private_Q_inv);
        generator_mat_t result_G = {0};
        generator_monomial_mul(&result_G,
                               &tmp_full_G,
                               &private_Q);
        memset(is_pivot_column, 0, sizeof(is_pivot_column));

        /*generator_mat_t result_G_copy;
        for(uint32_t i1=0; i1<K; i1++){
            for(uint32_t j1=0; j1)
        }*/
        generator_RREF(&result_G, is_pivot_column);
        /* note that the result is stored at i-1 as the first
         * public key element is just a seed */
        //if(i==1){
            monomial_transpose_N(&Q_guess_transpose, &private_Q);
            /*for(uint32_t i1=0; i1<N; i1++){
                if(guess.permutation[i1]!= private_Q_inv.permutation[i1]){
                    printf("Permutation of computing inverse Error\n");
                    break;
                }
                if(Q_guess_inv.coefficients[i1]!= private_Q_inv.coefficients[i1]){
                    printf("coefficient of computing inverse Error\n");
                    break;
                }
            }
            printf("Pivot column of G1 in key gen is givem by:\n");
            for(uint32_t i1=0; i1<N; i1++){
                printf("%d ", is_pivot_column[i1]);
            }
            printf("\n");*/
            printf("The private Q is given by:\n");
            for(uint32_t i1=0; i1<N; i1++){
                printf("%hd ",Q_guess_transpose.permutation[i1]);
            }
            printf("\n");
            /*for(uint32_t i1=0; i1<N; i1++){
                printf("%hd ",Q_guess_transpose.coefficients[i1]);
            }
            printf("\n");*/
        //}
        compress_rref(PK->SF_G[i],
                      &result_G,
                      is_pivot_column);
        compress_rref(SF_G_new[i],
                      &result_G,
                      is_pivot_column);
    }
} /* end LESS_keygen */

/// returns the number of opened seeds in the tree.
/// \param SK[in]: secret key
/// \param m[in]: message to sign
/// \param mlen[in]: length of the message to sign in bytes
/// \param sig[out]: signature
/// \return: x: number of leaves opened by the algorithm
size_t LESS_sign(const prikey_t *SK,
                 const char *const m,
                 const uint64_t mlen,
                 sign_t *sig) {
    
    printf("Hi I am in LESS_Sign: Reference Implementation\n");
    uint8_t g0_initial_pivot_flags [N_pad];
    uint8_t is_pivot_column[N_pad];

    /*         Private key expansion        */
    /* expand sequence of seeds for private inverse-monomial matrices */
    SHAKE_STATE_STRUCT sk_shake_state;
    initialize_csprng(&sk_shake_state, SK->compressed_sk, PRIVATE_KEY_SEED_LENGTH_BYTES);

    /* Generating seed for public code G_0 */
    unsigned char G_0_seed[SEED_LENGTH_BYTES];
    csprng_randombytes(G_0_seed, SEED_LENGTH_BYTES, &sk_shake_state);

    /* The first private key monomial is an ID matrix, no need for random
     * generation, hence NUM_KEYPAIRS-1 */
    unsigned char private_monomial_seeds[NUM_KEYPAIRS - 1][PRIVATE_KEY_SEED_LENGTH_BYTES];
    for (uint32_t i = 0; i < NUM_KEYPAIRS - 1; i++) {
        csprng_randombytes(private_monomial_seeds[i],
                           PRIVATE_KEY_SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }

    // generate the salt from a TRNG
    randombytes(sig->salt, HASH_DIGEST_LENGTH);

    /*         Ephemeral monomial generation        */
    unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
    csprng_randombytes(ephem_monomials_seed,
                       SEED_LENGTH_BYTES,
                       &sk_shake_state);

    /* create the prng for the "blinding" monomials for the canonical form computation */
    uint8_t cf_seed[SEED_LENGTH_BYTES];
    csprng_randombytes(cf_seed,
                       SEED_LENGTH_BYTES,
                       &sk_shake_state);
    SHAKE_STATE_STRUCT cf_shake_state;
    initialize_csprng(&cf_shake_state, cf_seed, SEED_LENGTH_BYTES);

    unsigned char seed_tree[NUM_NODES_SEED_TREE * SEED_LENGTH_BYTES] = {0};
    BuildGGM(seed_tree, ephem_monomials_seed, sig->salt);

    unsigned char linearized_rounds_seeds[T*SEED_LENGTH_BYTES] = {0};
    seed_leaves(linearized_rounds_seeds,seed_tree);

    /*         Public G_0 expansion                  */
    rref_generator_mat_t G0_rref;
    generator_sample(&G0_rref, G_0_seed);
    generator_get_pivot_flags (&G0_rref, g0_initial_pivot_flags);
    generator_mat_t full_G0, G0;
    generator_rref_expand(&full_G0, &G0_rref);

    monomial_t mu_tilde;
    monomial_action_IS_t pi_tilde[T];
    normalized_IS_t A_i = {0};

    LESS_SHA3_INC_CTX state;
    LESS_SHA3_INC_INIT(&state);

    for (uint32_t i = 0; i < T; i++) {
        monomial_sample_salt(&mu_tilde,
                             linearized_rounds_seeds + i * SEED_LENGTH_BYTES,
                             sig->salt,
                             i);
        generator_monomial_mul(&G0, &full_G0, &mu_tilde);
        memset(is_pivot_column, 0, N_pad);
#if defined(LESS_REUSE_PIVOTS_SG)
        uint8_t permuted_pivot_flags[N_pad];
        for (uint32_t t = 0; t < N; t++) {
            permuted_pivot_flags[mu_tilde.permutation[t]] = g0_initial_pivot_flags[t];
        }
        if (generator_RREF_pivot_reuse(&G0, is_pivot_column, permuted_pivot_flags, SIGN_PIVOT_REUSE_LIMIT) == 0) {
            return 0;
        }
#else
        if (generator_RREF(&G0, is_pivot_column) == 0) {
            return 0;
        }
#endif
        //Extra G_copy = G0 = RREF(G0.mu_tilde^T)
        if(i==0){
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    G_Copy.values[i1][j1] = G0.values[i1][j1];
                }
            }
        }
        ///////////////////////////////////////////
        // just copy the non IS
        uint32_t ctr = 0;
        for(uint32_t j = 0; j < N-K; j++) {
            while (is_pivot_column[ctr]) {
                ctr += 1;
            }
            /// copy column
            for (uint32_t k = 0; k < K; k++) {
                A_i.values[k][j] = G0.values[k][ctr];
            }
            ctr += 1;
        }
        POSITION_T piv_idx = 0;
        for(uint32_t col_idx = 0; col_idx < N; col_idx++) {
            POSITION_T row_idx = 0;
            for(uint32_t t = 0; t < N; t++) {
               if (mu_tilde.permutation[t] == col_idx) {
                   row_idx = t;
                   break;
               }
            }
            if(is_pivot_column[col_idx] == 1) {
               pi_tilde[i].permutation[piv_idx] = row_idx;
               piv_idx++;
            }
        }

        blind(&A_i, &cf_shake_state);
        const int t = CF(&A_i);
        if(i==0){
            normal_mat_copy_N_NK(&A_i_Copy, &A_i);
            CosetRep(cf_monom_actions_check, &pi_tilde[i]);
        }
            
        if (t == 0) {
            *(linearized_rounds_seeds + i*SEED_LENGTH_BYTES) += 1;
            i -= 1;
        } else {
            // NOTE: as we increase the size of the `normalized_IS_t`
            // we need to hash the values row by row.
#if defined(USE_AVX2) || defined(USE_NEON)
            for (uint32_t sl = 0; sl < K; sl++) {
                LESS_SHA3_INC_ABSORB(&state, A_i.values[sl], K);
            }
#else
            LESS_SHA3_INC_ABSORB(&state, (uint8_t *)&A_i, sizeof(normalized_IS_t));
#endif
        }
    }

    LESS_SHA3_INC_ABSORB(&state, (const uint8_t *)m, mlen);
    LESS_SHA3_INC_ABSORB(&state, sig->salt, HASH_DIGEST_LENGTH);

    /* Squeeze output */
    LESS_SHA3_INC_FINALIZE(sig->digest, &state);
    // (b_0, ..., b_{t-1})
    uint8_t fixed_weight_string[T] = {0};
    SampleChallenge(fixed_weight_string, sig->digest);

    uint8_t indices_to_publish[T];
    for (uint32_t i = 0; i < T; i++) {
        indices_to_publish[i] = !!(fixed_weight_string[i]);
    }

    int emitted_monoms = 0;
    memset(&sig->seed_storage, 0, SEED_TREE_MAX_PUBLISHED_BYTES);

    const uint32_t num_seeds_published =
            GGMPath(seed_tree,
                           indices_to_publish,
                           (unsigned char *) &sig->seed_storage);

    uint8_t seed_storage_faulted[SEED_TREE_MAX_PUBLISHED_BYTES];
    const uint32_t num_seeds_published_faulted =
            GGMPath_faulted(seed_tree,
                           indices_to_publish,
                           (unsigned char *) seed_storage_faulted);
    printf("seed_storage_faulted: %d\n", num_seeds_published_faulted);

    monomial_action_IS_t mono_action;
    for (uint32_t i = 0; i < T; i++) {
        monomial_t Q_to_multiply;
        if (fixed_weight_string[i] != 0) {
            const int sk_monom_seed_to_expand_idx = fixed_weight_string[i];
            monomial_sample_prikey(&Q_to_multiply,
                                   private_monomial_seeds[sk_monom_seed_to_expand_idx - 1]);
            monomial_compose_action(&mono_action, &Q_to_multiply, &pi_tilde[i]);
            CosetRep(sig->cf_monom_actions[emitted_monoms], &mono_action);
            emitted_monoms++;
        }
    }

    unsigned char seed_tree_new[NUM_NODES_SEED_TREE * SEED_LENGTH_BYTES] = {0};
    uint32_t rebuilding_seeds_went_fine_new;
    rebuilding_seeds_went_fine_new = RebuildGGM_new(seed_tree_new,
                                                          indices_to_publish,
                                                          (unsigned char *) seed_storage_faulted,
                                                          sig->salt);
    if (!rebuilding_seeds_went_fine_new) {
        printf("Error seed_storage_faulted\n");
        return 0;
    }
    unsigned char linearized_rounds_seeds_new[T*SEED_LENGTH_BYTES] = {0};
    seed_leaves_new(linearized_rounds_seeds_new,seed_tree_new);
    //int t = LOG2(T);
    int employed_monoms = 0;
    for (uint32_t i = 0; i < 6; i++) {
        //monomial_t Q_to_multiply;
        if (fixed_weight_string[i] != 0) {
            printf("Sign: %d\n", i);
            const int sk_monom_seed_to_expand_idx = fixed_weight_string[i];
            printf("emitted_monos: %d %d\n",i,sk_monom_seed_to_expand_idx-1);
            monomial_sample_salt(&mu_tilde,
                                 linearized_rounds_seeds_new + i * SEED_LENGTH_BYTES,
                                 sig->salt,
                                 i);
            generator_mat_t G_prime;
            generator_monomial_mul(&G_prime, &full_G0, &mu_tilde);
            memset(is_pivot_column, 0, N_pad);
#if defined(LESS_REUSE_PIVOTS_VY)
            uint8_t permuted_pivot_flags_new[N_pad] = {0};

            for (uint32_t t = 0; t < N; t++) {
                permuted_pivot_flags_new[mu_tilde.permutation[t]] = g0_initial_pivot_flags[t];
            }
            if (generator_RREF_pivot_reuse(&G_prime,is_pivot_column, permuted_pivot_flags_new, VERIFY_PIVOT_REUSE_LIMIT) == 0) {
                return 0;
            }
#else
            if (generator_RREF(&G_prime, is_pivot_column) == 0) {
                return 0;
            }
#endif
            POSITION_T piv_idx = 0;
            for(uint32_t col_idx = 0; col_idx < N; col_idx++) {
                POSITION_T row_idx = 0;
                for(uint32_t t = 0; t < N; t++) {
                if (mu_tilde.permutation[t] == col_idx) {
                    row_idx = t;
                    break;
                }
                }
                if(is_pivot_column[col_idx] == 1) {
                pi_tilde[i].permutation[piv_idx] = row_idx;
                piv_idx++;
                }
            }

            CosetRep(cf_monom_actions_check, &pi_tilde[i]);
            for(uint32_t i1=0; i1<N; i1++){
                P_tilde.permutation[i1] = i1;
                P_tilde.coefficients[i1] =1;
            }
            generator_mat_t G_check;
        #ifdef LESS_REUSE_PIVOTS_VY
            uint8_t g0_permuted_pivot_flags[N];
            apply_cf_action_to_G_with_pivots_new(&G_check,
                                        &full_G0,
                                        cf_monom_actions_check,
                                        g0_initial_pivot_flags,
                                        g0_permuted_pivot_flags, &P_tilde);

            //Check whether G_check1 = full_G0.P_tilde?
            generator_mat_t G_check1;
            for(uint32_t i1=0; i1<K; i1++){
                for(uint64_t j1=0; j1<N; j1++){
                    G_check1.values[i1][j1] = full_G0.values[i1][P_tilde.permutation[j1]];
                    if(G_check.values[i1][j1]!=G_check1.values[i1][j1]){
                        printf("Error !!!!!!!!\n");
                        break;
                    }
                }
            }
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<K; j1++)
                    S_tilde.value[i1][j1] =0;
                S_tilde.value[i1][i1] =1;
            }
            generator_mat_t G_check_copy, G_check2;
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++)
                    G_check_copy.values[i1][j1] = G_check.values[i1][j1];
            }
            uint8_t is_pivot_column_check[N_pad];
            memset(is_pivot_column_check, 0, N_pad);
            const int ret_check1 = generator_RREF_pivot_reuse_new(&G_check, is_pivot_column,
                                                g0_permuted_pivot_flags,
                                                VERIFY_PIVOT_REUSE_LIMIT, &S_tilde);
        #else
            printf("I am in else part\n");
            apply_cf_action_to_G(&G_check, &full_G0, cf_monom_actions_check);
            memset(is_pivot_column_check, 0, N_pad);
            const int ret_check1 = generator_RREF(&G_check, is_pivot_column);
        #endif
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    FQ_ELEM sum = 0;
                    for(uint32_t k1=0; k1<K; k1++){
                        sum = fq_add(sum, fq_mul(S_tilde.value[i1][k1],G_check_copy.values[k1][j1]));
                    }
                    G_check2.values[i1][j1] = sum;
                    if(G_check2.values[i1][j1]!=G_check.values[i1][j1]){
                        printf("Okay 4 in sign!!!!!!!!!!!!!!!!\n");
                        break;
                    }
                }
            }
            if(ret_check1 == 0) {
                printf("Error in ret_check1\n");
                return 0;
            }
            for(uint32_t j1 = 0; j1 < K; j1++){
                for(uint32_t i1=0; i1<K; i1++){
                    if(i1==j1)
                        printf("%hd ", G_check.values[i1][j1]);
                    else{
                        if(G_check.values[i1][j1]!=0){
                            printf("Error in generation of G\n");
                            break;
                        }
                    }
                }
            }
            printf("\n");
            for(uint32_t j1 = 0; j1 < N; j1++){
                if(is_pivot_column[j1]==1 && j1>=K){
                    printf("j1: %d\n", j1);
                }
            }
                //normalized_IS_t A_i_check1;
            uint32_t ctr_check1 = 0;
            for(uint32_t j1 = 0; j1 < N-K; j1++) {
                while (is_pivot_column[ctr_check1]) {
                    ctr_check1 += 1;
                }
                /// copy column
                for (uint32_t k = 0; k < K; k++) {
                    A_i_check_sign.values[k][j1] = G_check.values[k][ctr_check1];
                }
                ctr_check1 += 1;
            }
                //Extra
            normalized_IS_t A_i_check_1_1;
            for(uint32_t j1 = 0; j1 < N-K; j1++) {
                for (uint32_t k = 0; k < K; k++) {
                    A_i_check_1_1.values[k][j1] = G_check.values[k][j1+K];
                    if(A_i_check_sign.values[k][j1]!=A_i_check_1_1.values[k][j1]){
                        printf("Error 2!!!!!!!!!\n");
                        break;
                    }
                }
            }
            normal_mat_copy_N_NK(&B_i_copy, &A_i_check_sign);
            for(uint32_t j1 = 0; j1 < N; j1++) {
                for (uint32_t k = 0; k < K; k++) {
                    if(j1<K){
                        if( k==j1 && G_check.values[k][j1]!=1){
                            printf("Error in calculating identity\n");
                            break;
                        }
                            if( k!=j1 && G_check.values[k][j1]!=0){
                            printf("Error in calculating identity\n");
                            break;
                        }
                    }
                    else{
                        if(G_check.values[k][j1]!=B_i_copy.values[k][j1-K]){
                            printf("Error in calculating the non pivot column\n");
                            break;
                        }
                    }
                }
            }
            for(uint32_t i1=0; i1<K; i1++){
                Q_r_sign.permutation[i1] = i1;
                Q_r_sign.coefficients[i1] = 1;
            }
            for(uint32_t i1=0; i1<N-K; i1++){
                Q_c_sign.permutation[i1] = i1;
                Q_c_sign.coefficients[i1] = 1;
            }
            const int r_check1 = CF_new(&A_i_check_sign, &Q_r_sign, &Q_c_sign);
            if (r_check1 == 0) {
                printf("Error in r_check1\n");
                return 0;
            }
            monomial_mat_K(&Q_r_sign_update, &Q_r_sign);
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N-K; j1++){
                    G_row_final_sign.values[Q_r_sign_update.permutation[i1]][j1] = fq_mul (B_i_copy.values[i1][j1], 
                                                    Q_r_sign_update.coefficients[i1]); 
                }
            }
            for(uint32_t j1=0; j1<N-K; j1++){
                for(uint32_t i1=0; i1<K; i1++){
                    G_column_final_sign.values[i1][j1] =fq_mul( G_row_final_sign.values[i1][Q_c_sign.permutation[j1]], 
                                                    Q_c_sign.coefficients[j1]); 
                }
            }

            for(uint32_t i1=0; i1<K; i1++){
            //printf("N: %d, K: %d\n", N, K);
                for(uint32_t j1=0; j1<N-K; j1++){
                    if(G_column_final_sign.values[i1][j1]!=A_i_check_sign.values[i1][j1]){
                        printf("Error in CF new: %d %d\n", i1, j1); 
                        break;
                    }
                }
            }
            ////////////////////////////////////////////////////
            uint8_t gi_initial_pivot_flags[N];
            expand_to_rref(&G0, SF_G_new[fixed_weight_string[i] - 1], gi_initial_pivot_flags);
            if (!CheckCanonicalAction(sig->cf_monom_actions[employed_monoms])) {
                return 0;
            }
            #if defined(LESS_REUSE_PIVOTS_VY)
            //generator_mat_t G_check;
            //monomial_t P_tilde_dash;
            initialize_monomial_N(&P_tilde_dash); // P_tilde_dash = I_{k}
            apply_cf_action_to_G_with_pivots_new(&G_prime,
                                             &G0,
                                             sig->cf_monom_actions[employed_monoms],
                                             gi_initial_pivot_flags,
                                             g0_permuted_pivot_flags, &P_tilde_dash);
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    G_check.values[i1][j1] = G0.values[i1][P_tilde_dash.permutation[j1]];
                    if(G_check.values[i1][j1]!=G_prime.values[i1][j1]){
                        printf("Error in calcution of G_prime\n");
                        break;
                    }
                }
            }
            invertible_mat_K S_tilde_dash;
            initialize_inv_K(&S_tilde_dash);
            const int ret = generator_RREF_pivot_reuse_new(&G_prime, is_pivot_column,
                                                       g0_permuted_pivot_flags,
                                                       VERIFY_PIVOT_REUSE_LIMIT, &S_tilde_dash);
            //generator_mat_t G_check1;
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    FQ_ELEM sum = 0;
                    for(uint32_t k1=0; k1<K; k1++){
                        sum = fq_add(sum, fq_mul(S_tilde_dash.value[i1][k1],G_check.values[k1][j1]));
                    }
                    G_check1.values[i1][j1] = sum;
                    if(G_check1.values[i1][j1]!=G_prime.values[i1][j1]){
                        printf("Okay 4 in sign!!!!!!!!!!!!!!!!\n");
                        break;
                    }
                }
            }

           // printf("I am in if statement\n");
#else
            apply_cf_action_to_G(&G_prime, &G0, sig->cf_monom_actions[employed_monoms]);
            const int ret = generator_RREF_new(&G_prime, is_pivot_column, &S_tilde_dash_i);
            printf("I am in else statement\n");
#endif  
            
            if(ret == 0) {
                return 0;
            }
            printf("The G_prime matrix is given by:\n");
            for(uint32_t j1 = 0; j1 < K; j1++){
                for(uint32_t i1=0; i1<K; i1++){
                    if(i1==j1)
                        printf("%hd ", G_prime.values[i1][j1]);
                    else{
                        if(G_prime.values[i1][j1]!=0){
                            printf("Error in generation of G\n");
                            break;
                        }
                    }
                }
            }
            printf("\n");
            
            for(uint32_t j1 = 0; j1 < N; j1++){
                if(is_pivot_column[j1]==1 && j1>=K){
                    printf("j1: %d\n", j1);
                }
            }
            employed_monoms++;
            uint32_t ctr = 0;
            normalized_IS_t Ai;
            for(uint32_t j = 0; j < N-K; j++) {
                while (is_pivot_column[ctr]) {
                    ctr += 1;
                }
            /// copy column
                for (uint32_t k = 0; k < K; k++) {
                    Ai.values[k][j] = G_prime.values[k][ctr];
                }
                ctr += 1;
            }
            normalized_IS_t A_i_check_1;
            for(uint32_t j1 = 0; j1 < N-K; j1++) {
                for (uint32_t k = 0; k < K; k++) {
                    A_i_check_1.values[k][j1] = G_prime.values[k][j1+K];
                    if(Ai.values[k][j1]!=A_i_check_1.values[k][j1]){
                        printf("Error 2 in vrfy!!!!!!!!!\n");
                        break;
                    }
                }
            }
            //monomial_t_K Q_r_dash;
            //monomial_t_NK Q_c_dash;
            for(uint32_t i1=0; i1<K; i1++){
                Q_r_vrfy.permutation[i1] = i1;
                Q_r_vrfy.coefficients[i1] = 1;
            }
            for(uint32_t i1=0; i1<N-K; i1++){
                Q_c_vrfy.permutation[i1] = i1;
                Q_c_vrfy.coefficients[i1] = 1;
            }
            //normalized_IS_t C_i_copy;
            normal_mat_copy_N_NK(&C_i_copy, &Ai);
            const int r = CF_new(&Ai, &Q_r_vrfy,&Q_c_vrfy);
            if (r == 0) {
                printf("Error in CF function in vrfy\n");
                return 0;
            }
            //normalized_IS_t G_row_final_vrfy;
            //normalized_IS_t G_column_final_vrfy;
            monomial_mat_K(&Q_r_vrfy_update, &Q_r_vrfy);
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N-K; j1++){
                    G_row_final_vrfy.values[Q_r_vrfy_update.permutation[i1]][j1] = fq_mul(C_i_copy.values[i1][j1], Q_r_vrfy_update.coefficients[i1]);
                }
            }
            for(uint32_t j1=0; j1<N-K; j1++){
                for(uint32_t i1=0; i1<K; i1++){
                    G_column_final_vrfy.values[i1][j1] =fq_mul( G_row_final_vrfy.values[i1][Q_c_vrfy.permutation[j1]], 
                                                    Q_c_vrfy.coefficients[j1]); 
                }
            }
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N-K; j1++){
                    if(G_column_final_vrfy.values[i1][j1]!=Ai.values[i1][j1]){
                        printf("Error in CF new: %d %d\n", i1, j1); 
                        break;
                    }
                }
            }

            int t4 = normal_mat_compare_N_NK(&Ai, &A_i_check_sign);
            printf("t4 in vrfy: %d\n", t4);

            monomial_inv_K(&Q_r_vrfy_update_inv, &Q_r_vrfy_update);
            monomial_mult_K(&Q_r_bar, &Q_r_vrfy_update_inv, &Q_r_sign_update);           
            monomial_inv_NK(&Q_c_sign_inv, &Q_c_sign);
            monomial_mult_NK(&Q_c_bar, &Q_c_vrfy, &Q_c_sign_inv);
            //Checking Q_r_bar^{-1}.Ai. Q_c_bar = A_i_check_sign
            normalized_IS_t A_i_check2, A_i_check3;
            monomial_inv_K(&Q_r_bar_inv, &Q_r_bar);
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N-K; j1++){
                    A_i_check2.values[Q_r_bar_inv.permutation[i1]][j1] = fq_mul(C_i_copy.values[i1][j1], Q_r_bar_inv.coefficients[i1]);
                }
            }
            for(uint32_t j1=0; j1<N-K; j1++){
                for(uint32_t i1=0; i1<K; i1++){
                    A_i_check3.values[i1][j1] =fq_mul( A_i_check2.values[i1][Q_c_bar.permutation[j1]], 
                                                    Q_c_bar.coefficients[j1]); 
                }
            }
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N-K; j1++){
                    if(A_i_check3.values[i1][j1]!=B_i_copy.values[i1][j1]){
                        printf("Error in first checking: %d %d\n", i1, j1); 
                        break;
                    }
                }
            }
            monomial_inv_K(&Q_r_bar_inv, &Q_r_bar);
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    G_check1.values[i1][j1] = fq_mul(full_G0.values[i1][P_tilde.permutation[j1]], P_tilde.coefficients[j1]);
                }
            }
            for(uint32_t i1=0; i1<K; i1++){
                for(uint32_t j1=0; j1<N; j1++){
                    FQ_ELEM sum = 0;
                    for(uint32_t k1=0; k1<K; k1++){
                        sum = fq_add(sum, fq_mul(S_tilde.value[i1][k1],G_check1.values[k1][j1]));
                    }
                    G_check2.values[i1][j1] = sum;
                    if(j1<K){
                        if(i1==j1 && G_check2.values[i1][j1]!=1){
                            printf("Error in second step!!!!!!!!!!!!!!!!\n");
                            break;
                        }
                        if(i1!=j1 && G_check2.values[i1][j1]!=0){
                            printf("Error in second step!!!!!!!!!!!!!!!!\n");
                            break;
                        }
                    }
                    else{
                        if(G_check2.values[i1][j1]!=B_i_copy.values[i1][j1-K]){
                            printf("Error in second step!!!!!!!!!!!!!!!!\n");
                            break;
                        }
                    }
                }
            }
            ////////////////////////////////
            //Checking S_tilde.G0.P_tilde = (I_K||A)
            /////////////////////////////////////////////////////////////////////
            for(uint32_t i1=0; i1<N; i1++){
                if(i1<K){
                    P_bar.permutation[i1] = Q_r_bar.permutation[i1];
                    P_bar.coefficients[i1] = Q_r_bar.coefficients[i1];
                }
                else{
                    P_bar.permutation[i1] = Q_c_bar.permutation[i1-K]+K;
                    P_bar.coefficients[i1] = Q_c_bar.coefficients[i1-K];
                }
            }
            monomial_inv(&P_tilde_inv, &P_tilde);
            monomial_mult_N(&mult_P_bar_P_tilde_inv, &P_bar, &P_tilde_inv);
            monomial_mult_N(&Q_guess, &P_tilde_dash, &mult_P_bar_P_tilde_inv);
            monomial_inv(&Q_guess_inv, &Q_guess);
            printf("The Q_guess matrix is given by:\n");
            for(uint32_t i1=0; i1<N; i1++){
                printf("%hd ",Q_guess_inv.permutation[i1]);
            }
            printf("\n");
            /*for(uint32_t i1=0; i1<N; i1++){
                printf("%hd ",Q_guess_inv.coefficients[i1]);
            }
            printf("\n");*/
        }
    }
    return num_seeds_published;
} /* end LESS_sign */

/// NOTE: non-constant time
/// \param PK[in]: public key
/// \param m[in]: message for which a signature was computed
/// \param mlen[in]: length of the message in bytes
/// \param sig[in]: signature
/// \return 0: on failure
///         1: on success
int LESS_verify(const pubkey_t *const PK,
                const char *const m,
                const uint64_t mlen,
                const sign_t *const sig) {
    //printf("Hi I am in LESS_vrfy: Reference Implementation\n");
    uint8_t fixed_weight_string[T] = {0};
    uint8_t is_pivot_column[N_pad];
    uint8_t g0_initial_pivot_flags[N];
    uint8_t gi_initial_pivot_flags[N];
#ifdef LESS_REUSE_PIVOTS_VY
    uint8_t g0_permuted_pivot_flags[N];
#endif
    SampleChallenge(fixed_weight_string, sig->digest);

    uint8_t published_seed_indexes[T];
    for (uint32_t i = 0; i < T; i++) {
        published_seed_indexes[i] = !!(fixed_weight_string[i]);
    }

    unsigned char seed_tree[NUM_NODES_SEED_TREE * SEED_LENGTH_BYTES] = {0};
    uint32_t rebuilding_seeds_went_fine;
    rebuilding_seeds_went_fine = RebuildGGM(seed_tree,
                                                          published_seed_indexes,
                                                          (unsigned char *) &sig->seed_storage,
                                                          sig->salt);
    if (!rebuilding_seeds_went_fine) {
        return 0;
    }

    unsigned char linearized_rounds_seeds[T*SEED_LENGTH_BYTES] = {0};
    seed_leaves(linearized_rounds_seeds,seed_tree);

    int employed_monoms = 0;

    rref_generator_mat_t G0_rref;
    generator_sample(&G0_rref, PK->G_0_seed);

    generator_mat_t G0 = {0}, G0_full = {0};
    generator_mat_t G_prime = {0};
    monomial_t mu_tilde;
    normalized_IS_t Ai = {0};
    LESS_SHA3_INC_CTX state;
    LESS_SHA3_INC_INIT(&state);

    generator_get_pivot_flags(&G0_rref, g0_initial_pivot_flags);
    generator_rref_expand(&G0_full, &G0_rref);

    for (uint32_t i = 0; i < T; i++) {
        memset(is_pivot_column, 0, N_pad);
        if (fixed_weight_string[i] == 0) {
            monomial_sample_salt(&mu_tilde,
                                 linearized_rounds_seeds + i * SEED_LENGTH_BYTES,
                                 sig->salt,
                                 i);
            generator_monomial_mul(&G_prime, &G0_full, &mu_tilde);
#if defined(LESS_REUSE_PIVOTS_VY)
            uint8_t permuted_pivot_flags[N_pad] = {0};

            for (uint32_t t = 0; t < N; t++) {
                permuted_pivot_flags[mu_tilde.permutation[t]] = g0_initial_pivot_flags[t];
            }
            if (generator_RREF_pivot_reuse(&G_prime,is_pivot_column, permuted_pivot_flags, VERIFY_PIVOT_REUSE_LIMIT) == 0) {
                return 0;
            }
#else
            if (generator_RREF(&G_prime, is_pivot_column) == 0) {
                return 0;
            }
#endif
        } else {
            expand_to_rref(&G0, PK->SF_G[fixed_weight_string[i] - 1], gi_initial_pivot_flags);
            if (!CheckCanonicalAction(sig->cf_monom_actions[employed_monoms])) {
                return 0;
            }
    #if defined(LESS_REUSE_PIVOTS_VY)
            apply_cf_action_to_G_with_pivots(&G_prime,
                                             &G0,
                                             sig->cf_monom_actions[employed_monoms],
                                             gi_initial_pivot_flags,
                                             g0_permuted_pivot_flags);
            const int ret = generator_RREF_pivot_reuse(&G_prime, is_pivot_column,
                                                       g0_permuted_pivot_flags,
                                                       VERIFY_PIVOT_REUSE_LIMIT);

#else
            apply_cf_action_to_G(&G_prime, &G0, sig->cf_monom_actions[employed_monoms]);
            const int ret = generator_RREF_new(&G_prime, is_pivot_column, &S_tilde_dash_i);
           // printf("I am in else statement\n");
#endif  
if(ret == 0) {
                return 0;
            }
            employed_monoms++;
    }
        uint32_t ctr = 0;
        for(uint32_t j = 0; j < N-K; j++) {
            while (is_pivot_column[ctr]) {
                ctr += 1;
            }
            for (uint32_t k = 0; k < K; k++) {
                Ai.values[k][j] = G_prime.values[k][ctr];
            }
            ctr += 1;
        }
        const int r = CF(&Ai);
        if (r == 0) {
            return 0;
        }
    
#if defined(USE_AVX2) || defined(USE_NEON)
        for (uint32_t sl = 0; sl < K; sl++) {
            LESS_SHA3_INC_ABSORB(&state, Ai.values[sl], K);
        }
#else
        LESS_SHA3_INC_ABSORB(&state, (uint8_t *)&Ai, sizeof(normalized_IS_t));
#endif
    }

    uint8_t recomputed_digest[HASH_DIGEST_LENGTH] = {0};
    LESS_SHA3_INC_ABSORB(&state, (const uint8_t *) m, mlen);
    LESS_SHA3_INC_ABSORB(&state, sig->salt, HASH_DIGEST_LENGTH);
    /* Squeeze output */
    LESS_SHA3_INC_FINALIZE(recomputed_digest, &state);

    return (verify(recomputed_digest, sig->digest,
                   HASH_DIGEST_LENGTH) == 0);
} /* end LESS_verify */

